const Post = {
  data() {
    return {
      status: "",
      posts: [],
    };
  },
  methods: {
    add() {
      this.posts.unshift(this.status);
      this.status = "";
    },
    remove(index) {
      this.posts.splice(index, 1);
    },
  },
  template: `
    <div class="container">
    <h1>Status Post</h1>
    <div class="form-group">
      <label for="status" class="form-check-label">Status:</label>
      <input
        class="form-control"
        v-model="status"
        type="text"
        placeholder="Enter your Status"
        required
      />
      <button @click="add" class="btn btn-primary mt-2">Post</button>
    </div>
  
    <div v-if="posts.length > 0">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Status</th>
            <th scope="col">Function</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(str, index) in posts" :key="index">
            <td>{{ index + 1 }}</td>
            <td>{{ str }}</td>
            <td>
              <button @click="remove(index)" class="btn btn-primary">
                Delete
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
    `,
};

export default Post;
