<?php
// Config for database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "cos30043";
