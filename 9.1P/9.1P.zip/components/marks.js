const studentMarks = [
  { name: "Amy", mark: 90 },
  { name: "Bill", mark: 80 },
  { name: "Casey", mark: 78 },
  { name: "David", mark: 84 },
  { name: "Evan", mark: 92 },
  { name: "Felix", mark: 58 },
  { name: "Gaia", mark: 94 },
  { name: "John", mark: 70 },
  { name: "Kylie", mark: 86 },
  { name: "Ace", mark: 88 },
  { name: "Bob", mark: 72 },
  { name: "Charlie", mark: 95 },
  { name: "Diana", mark: 63 },
  { name: "Edward", mark: 91 },
  { name: "Fiona", mark: 84 },
  { name: "George", mark: 77 },
  { name: "Hannah", mark: 55 },
  { name: "Ivan", mark: 69 },
  { name: "Julia", mark: 80 },
];

const pageLength = 3;

const StudentMarks = {
  data() {
    return {
      page: 1,
      marks: studentMarks,
    };
  },
  methods: {
    setPage(page) {
      if (page < 1 || !Number.isInteger(page) || page > this.pages) {
        return;
      }
      this.page = page;
    },
  },
  computed: {
    pages() {
      const calculatedPages = Math.ceil(this.marks.length / pageLength);
      return calculatedPages < 1 ? 1 : calculatedPages;
    },
    pagedUnits() {
      const { page, marks } = this;
      const startIndex = (page - 1) * pageLength;
      const endIndex = startIndex + pageLength;
      return marks.slice(startIndex, endIndex);
    },
  },
  template: `
        <h1>Student Marks</h1>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col" id="studHeading">Code</th>
                        <th scope="col" id="markHeading">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="m in pagedUnits">
                        <td headers="studHeading">{{m.name}}</td>
                        <td headers="markHeading">{{m.mark}}</td>
                    </tr>
                </tbody>
            </table>
            <span>
                <button class="btn btn-light" @click="setPage(page - 1)">Previous</button>
                <button class="btn btn-light" v-if="page > 2" @click="setPage(page - 2)">...</button>
                <button class="btn btn-light" v-if="page > 1" @click="setPage(page - 1)">{{page - 1}}</button>
                <button class="btn btn-primary">{{page}}</button>
                <button class="btn btn-light" v-if="page < pages" @click="setPage(page + 1)">{{page + 1}}</button>
                <button class="btn btn-light" v-if="page + 1 < pages" @click="setPage(page + 2)">...</button>
                <button class="btn btn-light" @click="setPage(page + 1)">Next</button>
            </span>
        </div>
    `,
};

export default StudentMarks;
