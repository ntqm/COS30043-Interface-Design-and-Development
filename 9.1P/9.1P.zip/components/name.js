const StringTest = {
    data() {
        return {
            name: ""
        }
    },
    template: `
    <div class="container">
    <h1>String Test</h1>
    <div class="form-group">
        <label for="name" class="form-check-label">Enter Your Name:</label>
        <input
          class="form-control"
          v-model="name"
          type="text"
          placeholder="Name..."
          required
        />
        <p v-if="name.toLowerCase() === 'minh'">Awesome Name!</p>
        <p v-else-if="name === '' ">Please enter a name!</p>
        <p v-else>
            <i>{{name}}</i> is not my name!
        </p>
    </div>
    </div>
    `
}

export default StringTest;